package com.example.simulate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
