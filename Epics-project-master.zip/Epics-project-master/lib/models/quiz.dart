class Quiz
{
  String question;
  String correctAns;
  List<String> incorrectAns;

  Quiz(this.question,this.correctAns,this.incorrectAns);
}