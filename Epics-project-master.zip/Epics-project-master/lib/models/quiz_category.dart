class QuizCategory {
  String name;
  int id;
  String difficulity;

  QuizCategory(this.name, this.id, this.difficulity);
}
